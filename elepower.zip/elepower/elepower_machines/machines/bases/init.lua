
dofile(elepm.modpath.."/machines/bases/crafter.lua")
dofile(elepm.modpath.."/machines/bases/generator.lua")
dofile(elepm.modpath.."/machines/bases/fluid_generator.lua")
dofile(elepm.modpath.."/machines/bases/storage.lua")
