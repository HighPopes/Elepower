
fluid_tanks.register_tank("elepower_dynamics:portable_tank", {
	description = "Portable Tank",
	capacity    = 8000,
	accepts     = true,
	tiles       = {
		"elepower_tank_base.png", "elepower_tank_side.png", "elepower_tank_base.png^elepower_power_port.png",
	}
})
