-- Elepower Compatibility registrations

dofile(elepd.modpath.."/compat/basic_materials.lua")
