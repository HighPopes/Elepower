
local mp = elenuclear.modpath .. "/machines/"

dofile(mp.."enrichment_plant.lua")
dofile(mp.."fission_reactor.lua")
dofile(mp.."fusion_reactor.lua")
dofile(mp.."heat_exchanger.lua")
dofile(mp.."solar_neutron_activator.lua")

