
local mp = elethermal.modpath .. "/machines/"

dofile(mp.."evaporation_plant.lua")
