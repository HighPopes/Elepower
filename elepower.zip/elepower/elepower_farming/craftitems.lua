
minetest.register_craftitem("elepower_farming:resin", {
	description = "Resin",
	inventory_image = "elefarming_resin.png",
	groups = {resin = 1}
})
